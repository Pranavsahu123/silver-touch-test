<!DOCTYPE html>
<html>
<head>
    <title>Product List</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
    table,
    th,
    td {
        border: 1px solid black;
        border-collapse: collapse;
        padding: 5px;
    }

    .fa {
        padding: 5px;
    }

    .btn {
        background: lightskyblue;
        margin: 10px auto;
        margin-left: 500px;
    }

    .btn a {
        color: white;
        text-decoration: none;
    }
    </style>
</head>

<body>
    <?php
	include("header.php");
    include(dirname(__FILE__)."\classes\category.classes.php");
	?>

    <div class="container mt-4">
        <h3>Add New Category: </h3>
        <hr>
        <form method="POST" action="includes/category.inc.php" enctype="multipart/form-data">
            <div class="insert">
                <span class="error">* </span>
                <label for="catName">Product Name:</label><br>
                <input type="text" class="same" name="category_name" placeholder="Category Name" required="">
                <span class="error">*</span><br><br>

                <span class="error">*</span>
                <label for="InputImage">Upload image</label><br>
                <input type="file"  name="file" placeholder="Select image" required="">
                <span class="error">*</span><br><br>

                <span class="error">*</span>
                <label for="category">Parent Category:</label><br>
                <?php
                $obj = new category(); 
                $data= $obj->getcategory();
                ?>
                <select name="cat_parent_id" id="category">
                    <span class="error">*</span><br><br>
                    <?php
                foreach ($data as $value){ 
                ?>
                <option value=<?php print_r($value['cat_id']); ?>><?php print_r($value['parent_cat_name']); ?><option>
                <?php
                    } 
                ?>
                </select><br><br>     
                         
                <input type="submit" name="submit" class="btn" value="Add Category">
            </div>           
    </div>
    <?php
?>
</body>

</html>