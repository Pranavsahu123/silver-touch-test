<?php

if(isset($_POST['submit'])){
// print_r($_POST);
// exit;
// Grabbing the data
$product_name = $_POST['product'];
$product_desc = $_POST['description'];
$category_id = $_POST['cat_id'];
$file = $_FILES["file"]; // image or documents use $_FILES
$filename = $file["name"];
$fileerror = $file["error"];
$filetmp = $file["tmp_name"];
$destination = "../images/".$filename;
move_uploaded_file($filetmp, $destination);

include("../classes/product.classes.php");
$obj = new product();
$data = $obj->insertProduct($product_name,$product_desc,$filename,$category_id);

}

?>