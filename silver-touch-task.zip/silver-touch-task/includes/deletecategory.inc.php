<?php
include("../classes/category.classes.php");
$obj = new category();
$data = $obj->deleteCategory();


?>