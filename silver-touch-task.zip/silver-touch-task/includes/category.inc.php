<?php

if(isset($_POST['submit'])){

// Grabbing the data
$cat_name = $_POST['category_name'];
$cat_parent_id = $_POST['cat_parent_id'];
$file = $_FILES["file"]; // image or documents use $_FILES
$filename = $file["name"];
$fileerror = $file["error"];
$filetmp = $file["tmp_name"];
$destination = "../images/".$filename;
move_uploaded_file($filetmp, $destination);

include("../classes/category.classes.php");
// include("../classes/signup-contr.classes.php");
$obj = new category();
$data = $obj->insertcategory($cat_name,$filename,$cat_parent_id);

}

?>