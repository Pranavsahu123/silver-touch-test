<?php
include("../classes/product.classes.php");
$obj = new category();
$data = $obj->deleteProduct();


?>