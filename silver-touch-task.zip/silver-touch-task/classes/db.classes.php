<?php
	class db_connection{

		private $servername = "localhost";
		private $username = "root";
		private $password = "";
		private $database = "silver_touch";

		public $conn;

		//connection  

		public function connect(){
		
		    $this->conn = new mysqli($this->servername, $this->username,$this->password,$this->database);
		    if($this->conn -> connect_error) {
			 die("connection failed: " . $this->conn -> connect_error);
		    }else{
				return $this->conn;
			// echo "Connection Successfull ";
		    }
		}
    }
?>