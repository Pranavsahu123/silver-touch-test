<?php
include ("db.classes.php");

class category{
   
   
public function displayData($id=null){
    $obj = new db_connection();
    if($id==null){
        $selectquery = "SELECT * FROM categories"; 
        $result = $obj->connect()->query($selectquery);
			if($result){
				while($row = $result->fetch_assoc()){
					$data[] = $row;
				}
			}   
    }else{
        $selectquery = "SELECT * FROM categories WHERE cat_id = $id";  
        $result = $obj->connect()->query($selectquery); 
        $data=$result->fetch_assoc();
    }	
            return $data;

}

public function getCategory(){
    $obj = new db_connection();
    $selectquery = "SELECT * FROM parent_category";
			$result = $obj->connect()->query($selectquery);
			if($result){
				while($row = $result->fetch_assoc()){
					$data[] = $row;
				}
				return $data;
			}
}

public function insertcategory($cat_name,$filename,$cat_parent_id){
   
    $obj = new db_connection();
    $insertquery = "INSERT INTO categories (cat_name , cat_image , cat_parent_id ) VALUES ('$cat_name' , '$filename' , '$cat_parent_id' )";
    $result = $obj->connect()->query($insertquery);
    if($result){
        header("location: ../category_list.php");
    }
    else{
        header("location: ../add_category.php");
    }
}

public function updateCategoryData($post){
    $obj = new db_connection();
    $cat_name = $post['category'];
    $editid 	 =  $post['id'];
    $image 	 =  $post['image'];
    $parent_cat_id=$post['parent_category_name'];
    $file = $_FILES["file"];

    if(!empty($cat_name) && !empty($editid) ){
				
        if (!empty($_FILES['file']['tmp_name'])){
            $filename = $file["name"];
            $fileerror = $file["error"];
            $filetmp = $file["tmp_name"];
            $destination = "../images/".$filename;
            move_uploaded_file($filetmp, $destination);

            $updatequery = "UPDATE `categories` SET `cat_name`='$cat_name',`cat_image`='$filename',`cat_parent_id`=$parent_cat_id WHERE Id = $editid";
        }else{
            $updatequery = "UPDATE `categories` SET `cat_name`='$cat_name',`cat_image`='$image',`cat_parent_id`=$parent_cat_id WHERE Id = $editid";
        }
    
        $result = $obj->connect()->query($updatequery);
        
        if($result){
            return $result;
            header('location:../category_list.php');
        }else{
            echo "Not Updated";
        }
    }
}


public function deleteCategory($id=null){
    $obj = new db_connection();
if($id == null){
   $deletequery= "DELETE FROM categories ";
    $result = $obj->connect()->query($deletequery);
    header('location:../category_list.php');
}else{
    $deletequery = "DELETE FROM categories WHERE cat_id = $id";
    $result = $obj->connect()->query($deletequery);
    header('location:../category_list.php');

}
}

}
    


?>