<?php
include ("db.classes.php");

class product{

    public function displayData($id=null){
        $obj = new db_connection();
        if($id==null){
            $selectquery = "SELECT * FROM products as p LEFT JOIN categories as c ON p.category_id=c.cat_id"; 
            $result = $obj->connect()->query($selectquery);
                if($result){
                    while($row = $result->fetch_assoc()){
                        $data[] = $row;
                    }
                }   
        }else{
            $selectquery = "SELECT * FROM products Where prod_id = $id";  
            $result = $obj->connect()->query($selectquery); 
            $data=$result->fetch_assoc();
        }	
                return $data;
    
    }
    
    public function insertProduct($prod_name,$prod_desc,$filename,$cat_id){
   
        $obj = new db_connection();
        $insertquery = "INSERT INTO products (prod_name ,prod_descp ,prod_image ,category_id ) VALUES ('$prod_name' , '$prod_desc' ,'$filename', '$cat_id' )";
        $result = $obj->connect()->query($insertquery);
        if($result){
            header("location: ../product_list.php");
        }
        else{
            header("location: ../add_product.php");
        }
    }
    public function getcatname(){
        $obj = new db_connection();

        $selectquery = "SELECT * FROM categories";  
        $result = $obj->connect()->query($selectquery); 
        if($result){
            while($row = $result->fetch_assoc()){
                $data[] = $row;
            }
        }
        return $data;
       
    }
    public function deleteProduct($id=null){
        $obj = new db_connection();
    if($id == null){
       $deletequery= "DELETE FROM products ";
        $result = $obj->connect()->query($deletequery);
        header('location:../product_list.php');
    }else{
        $deletequery = "DELETE FROM products WHERE prod_id = $id";
        $result = $obj->connect()->query($deletequery);
        header('location:../product_list.php');

        // return $result;
    }
    }

    public function updateProductData($post){
        print_r($post);
        exit;
        $obj = new db_connection();
        $prod_name = $post['product'];
        $prod_descp = $post['description'];
        $category_id = $post['prod_category_name'];
        $editid 	 =  $post['id'];
        $image 	 =  $post['image'];
        $file = $_FILES["file"];
    
        if(!empty($prod_name) && !empty($editid) ){
                    
            if (!empty($_FILES['file']['tmp_name'])){
                $filename = $file["name"];
                $fileerror = $file["error"];
                $filetmp = $file["tmp_name"];
                $destination = "../images/".$filename;
                move_uploaded_file($filetmp, $destination);
    
                $updatequery = "UPDATE `products` SET `prod_name`='$prod_name',`prod_descp`='$prod_descp',` 	prod_image`='$filename',`category_id`=$category_id WHERE Id = $editid";
            }else{
                $updatequery = "UPDATE `products` SET `prod_name`='$prod_name',`prod_descp`='$prod_descp',`prod_image`='$image',`category_id`=$category_id WHERE Id = $editid";
            }
        
            $result = $obj->connect()->query($updatequery);
            
            if($result){
                return $result;
                header('location:../product_list.php');
            }else{
                echo "Not Updated";
            }
        }
    }
    
    

}