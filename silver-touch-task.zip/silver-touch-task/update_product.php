<!DOCTYPE html>
<html>

<head>
    <title>Update Product Details</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
    .error {
        color: red;
    }

    img {
        margin: 1%;
        height: 100px;
        width: auto;
    }

    .btn {
        color: black;
        background: lightgreen;
    }
    </style>
</head>

<body>
    <?php
	include("header.php");
    include(dirname(__FILE__)."\classes\product.classes.php");
   
    $obj = new product();


	if(isset($_POST['update'])){
        // print_r($_POST);
        // exit;
		$obj->updateProductData($_POST);

	}

	if(isset($_GET['deleteid'])){
		$delId = $_GET['deleteid'];
		$obj->deleteProduct($delId);
        header('location:category_list.php');
	}


	if(isset($_GET['editid'])){
		// print_r($_GET);
        // exit;
		$editId = $_GET['editid'];
		$record = $obj->displayData($editId);
    
        //   print_r($record);
        //   exit;
	?>

    <div class="container">
        <h3>Update Product: </h3>
        <hr>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">
            <div class="insert">
                <span class="error">*</span>
                <label for="catName">Product Name:</label><br>
                <input type="text" class="same" name="product" value="<?php echo $record['prod_name']; ?>"
                    placeholder="Enter name" required="">
                <span class="error">*</span><br><br>

                <span class="error">*</span>
                <label for="description">Description:</label><br>
                <textarea id="descrip" name="description" rows="4" cols="50"
                    required=""><?php echo $record['prod_descp']; ?></textarea>
                <span class="error">*</span><br><br>

                <span class="error">*</span>
                <label for="InputImage">Upload image</label><br>
                <input type="file" class="same" name="file"><br>

                <img src="<?php echo 'http://localhost/pranav/silver-touch-task/images/' . $record["prod_image"] ?>">
                <br><br>

                <span class="error">*</span>
                <label for="category">Category:</label><br>

                <?php 
                    $data= $obj->getcatname();
                    // print_r($data);
                    // exit;
                ?>
                <select name="prod_category_name" id="category">
                    <?php
                foreach ($data as $value){ 
                    
                    if($record['category_id'] == $value['cat_id']){
                       
                ?>
                    <option value=<?php print_r($value['cat_id']); ?>><?php print_r($value['cat_name']); ?></option>
                    <?php
                    }
                }
                foreach ($data as $value){ 
                    if($record['category_id'] != $value['cat_id']){
                        echo "hello2";

                ?>
                    <option value=<?php print_r($value['cat_id']); ?>><?php print_r($value['cat_name']); ?></option>

                    <?php
                    }
                    } 
                ?>
                </select><br><br>


                <input type="hidden" name="id" value="<?php echo $record['prod_id']; ?>">
                <input type="hidden" name="image" value="<?php echo $record["prod_image"]; ?>">
                <input type="submit" name="update" class="btn" value="Update Product">
            </div>
    </div>
    <?php
    }
	?>

</body>

</html>