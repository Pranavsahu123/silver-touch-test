<!DOCTYPE html>
<html>
<head>
	<title>Category List</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<style>
		table,th,td{
			border: 2px solid black;
			border-collapse: collapse;
			padding: 5px;
		}
		.fa{
			padding: 5px;
		}
		.btn{
			background: green;
			margin: 10px auto;
		}
		.btn1{
			
			margin: 10px 0 10px 200px;
		}
		.btn a{
			color: white;
			text-decoration: none;
		}
		td a{
        color:black;
        background: lightgreen;
    }
	</style>
</head>
<body>
<?php
	include("header.php");
	include(dirname(__FILE__)."\classes\category.classes.php");
?>
	<div class="container mt-4">
		<h1 class="emp">Category List:</h1>
		<button class="btn"><a href = "add_category.php">Add New Category</a></button>
		<button class="btn1" style="display="><a href = "includes/deletecategory.inc.php">Delete Category</a></button>
		<div class="table">
			<table>
					<th>Sr No</th>
					<th>Category Name</th>
					<th>Category Image (Thumb)</th>
					<th colspan="2">Action</th>
					<tr>
						<?php
                        $obj = new category();
							$data = $obj->displayData();
							$i=1;
							foreach ($data as $value){
						?>
						<tr>
							<td><?php echo $i; ?></td>
							<td><?php echo $value['cat_name']; ?></td>
							<td><img src="<?php echo 'http://localhost/pranav/silver-touch-task/images/' . $value["cat_image"] ?>" height="59px" width="100px"></td>
							<td>
								<a href="update_category.php?editid=<?php echo $value['cat_id']; ?>" style="color: Black">Edit</a>
								<a href="update_category.php?deleteid=<?php echo $value['cat_id']; ?>" style="color: Black">Delete</a>
							</td>
						</tr>
						<?php	
						$i++;
						} // foreach close
						?>
					</tr>
			</table>
		</div>
	</div>
</body>
</html>