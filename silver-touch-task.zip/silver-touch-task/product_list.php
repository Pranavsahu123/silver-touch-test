<!DOCTYPE html>
<html>

<head>
    <title>Product List</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
    table,
    th,
    td {
        border: 2px solid black;
        border-collapse: collapse;
        padding: 5px;
    }

    .fa {
        padding: 5px;
    }

    .btn {
        background: green;
        margin: 10px auto;
        /* margin-left: 500px;*/
    }

    .btn a {
        color: white;
        text-decoration: none;
    }

    td a {
        color: black;
        background: skyblue;
    }
    </style>
</head>

<body>
    <?php
	include("header.php");
	include(dirname(__FILE__)."\classes\product.classes.php");
	?>

    <div class="container mt-4">
        <h1 class="emp">Product List:</h1>
        <button class="btn"><a href="add_category.php">Add New Category</a></button><br><br>
        <label for="catName"><strong>Search: </strong> </label>
        <input type="text" class="same" name="prod_name" placeholder="Enter product Name" required="">
        <select name="prod_id" id="product">
            <span class="error">*</span>
            <option value="">--Select Category--
            <option>
        </select>
        <button type="button" class="btn btn-dark" onclick="search();">Search</button>
        <button class="btn1" style="display="><a href="includes/deleteproduct.inc.php">Delete Category</a></button>
        <div class="table">
            <table>
                <!-- <thead> -->
                <th>Sr No</th>
                <th>Product Name</th>
                <th>Product Image (Thumb)</th>
                <th>Category</th>
                <th colspan="2">Action</th>
                <!-- </thead> -->
                <!-- <tbody> -->
                <tr>
                    <?php
                        $obj = new Product();
							$data = $obj->displayData();
							$i=1;
							foreach ($data as $value){
						?>
                <tr>
                    <td><?php echo $i; ?></td>
                    <td><?php echo $value['prod_name']; ?></td>
                    <td><img src="<?php echo 'http://localhost/pranav/silver-touch-task/images/' . $value["prod_image"] ?>"
                            height="59px" width="100px"></td>

                    <td><?php echo $value['cat_name']; ?></td>
                    <!-- we need to display dynamically category -->

                    <td>
                        <a href="update_product.php?editid=<?php echo $value['prod_id']; ?>"
                            style="color: Black">Edit</a>
                        <a href="update_product.php?deleteid=<?php echo $value['prod_id']; ?>"
                            style="color: Black">Delete</a>
                    </td>
                </tr>
                <?php	
				    $i++;
					} // foreach close
				?>
                </tr>
                <!-- </tbody> -->
            </table>

            <script type="text/javascript" src="js/jquery.js"></script>

            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"
                integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1"
                crossorigin="anonymous">
            </script>
            <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"
                integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM"
                crossorigin="anonymous">
            </script>
            <script type="text/javascript">
            // Need  modification for onclick
            // $(document).ready(function() {
            // function search(){
            // // alert('hello ');
            // }});
            </script>
        </div> 
    </div> 
</body>
</html>