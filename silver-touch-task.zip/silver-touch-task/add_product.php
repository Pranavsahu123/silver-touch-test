<!DOCTYPE html>
<html>

<head>
    <title>Product List</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
    table,
    th,
    td {
        border: 1px solid black;
        border-collapse: collapse;
        padding: 5px;
    }

    .fa {
        padding: 5px;
    }

    .btn {
        background: lightskyblue;
        margin: 10px auto;
        margin-left: 500px;
    }

    .btn a {
        color: white;
        text-decoration: none;
    }
    </style>
</head>

<body>
    <?php
	include("header.php");
    include(dirname(__FILE__)."\classes\category.classes.php");

	?>

    <div class="container mt-4">
        <h3>Add New Product: </h3>
        <hr>
        <form method="POST" action="includes/product.inc.php" enctype="multipart/form-data">
            <div class="insert">
                <span class="error">*</span>
                <label for="catName">Product Name:</label><br>
                <input type="text" class="same" name="product" placeholder="Product Name" required="">
                <span class="error">*</span><br><br>

                <span class="error">*</span>
                <label for="description">Description:</label><br>
                <textarea id="descrip" name="description" rows="4" cols="50" required=""></textarea>
                <span class="error">*</span><br><br>
                
                <span class="error">*</span>
                <label for="InputImage">Upload image</label><br>
                <input type="file"  name="file" placeholder="Select image" required="">
                <span class="error">*</span><br><br>
                
                <span class="error">*</span>
                <label for="category">Category:</label><br>
                <?php
                $obj = new category(); 
                $data= $obj->displayData();
                ?>
                <select name="cat_id" id="category_name">
                    <span class="error">*</span><br><br>
                <?php
                foreach ($data as $key=>$value){ 

                ?>
                <option value=<?php echo($value['cat_id']); ?>><?php echo($value['cat_name']); ?><option>
                <?php   
                    } 
                ?>
                </select><br><br>         
                
                <input type="submit" name="submit" class="btn" value="Add Product">
            </div>           
    </div>
    
</body>

</html>