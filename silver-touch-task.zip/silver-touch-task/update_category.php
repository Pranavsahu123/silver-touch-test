<!DOCTYPE html>
<html>

<head>
    <title>Update Category Details</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"
        integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <style>
    .error {
        color: red;
    }

    img {
        margin: 1%;
        height: 100px;
        width: auto;
    }
    .btn{
        color:black;
        background: lightgreen;
    }
    </style>
</head>

<body>
    <?php
	include("header.php");
    include(dirname(__FILE__)."\classes\category.classes.php");
  
    $obj = new category();


	if(isset($_POST['update'])){
        // print_r($_POST);
        // exit;
		$obj->updateCategoryData($_POST);

	}//if isset close	

	if(isset($_GET['deleteid'])){
		$delId = $_GET['deleteid'];
		$obj->deleteCategory($delId);
	}


	if(isset($_GET['editid'])){
		
		$editId = $_GET['editid'];
		$record = $obj->displayData($editId);
    
        //   print_r($record);
        //   exit;
	?>

    <div class="container">
        <h3>Update Category: </h3>
        <hr>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">
            <div class="insert">
                <span class="error">*</span>
                <label for="catName">Category Name:</label><br>
                <input type="text" class="same" name="category" value="<?php echo $record['cat_name']; ?>"
                    placeholder="Enter name" required="">
                <span class="error">*</span><br><br>

                <span class="error">*</span>
                <label for="InputImage">Upload image</label><br>
                <input type="file" class="same" name="file"><br>
               
                <img src="<?php echo 'http://localhost/pranav/silver-touch-task/images/' . $record["cat_image"] ?>">
                <br><br>

                <span class="error">*</span>
                <label for="category">Parent Category:</label><br>

                <?php 
                    $data= $obj->getCategory();
                    ?>
                <select name="parent_category_name" id="category">
                    <?php
                foreach ($data as $value){ 
                    if($record['cat_parent_id'] == $value['cat_id']){
                ?>
                    <option value=<?php print_r($value['cat_id']); ?>><?php print_r($value['parent_cat_name']); ?></option>
                    <?php
                    }
                }
                foreach ($data as $value){ 
                    if($record['cat_parent_id'] != $value['cat_id']){
                ?>
                    <option value=<?php print_r($value['cat_id']); ?>><?php print_r($value['parent_cat_name']); ?></option>

                    <?php
                    }
                    } 
                ?>
                </select><br><br>
               
                <input type="hidden" name="id" value="<?php echo $record['cat_id']; ?>">
                <input type="hidden" name="image" value="<?php echo $record["cat_image"]; ?>">
                <input type="submit" name="update" class="btn" value="Update Category">
            </div>
    </div>
    <?php
    }
	?>

</body>

</html>